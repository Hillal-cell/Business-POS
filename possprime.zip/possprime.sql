-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2023 at 04:15 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `possprime`
--

-- --------------------------------------------------------

--
-- Table structure for table `audits`
--

CREATE TABLE `audits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `action` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `business_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audits`
--

INSERT INTO `audits` (`id`, `action`, `user_id`, `category`, `business_id`, `created_at`, `updated_at`) VALUES
(72, 'Product Category registered successfully', 43, 2, 38, '2023-08-12 04:50:09', '2023-08-12 04:50:09'),
(73, 'Unit registered successfully', 43, 4, 38, '2023-08-12 04:50:53', '2023-08-12 04:50:53'),
(74, 'Product registered successfully', 43, 3, 38, '2023-08-12 04:51:34', '2023-08-12 04:51:34'),
(75, 'Stock registered successfully', 43, 6, 38, '2023-08-12 04:53:04', '2023-08-12 04:53:04'),
(76, 'Product Category registered successfully', 43, 2, 38, '2023-08-13 13:55:09', '2023-08-13 13:55:09'),
(77, 'Product Category Updated successfully', 43, 2, 38, '2023-08-13 13:55:24', '2023-08-13 13:55:24'),
(78, 'Product Category Updated successfully', 43, 2, 38, '2023-08-13 13:56:24', '2023-08-13 13:56:24'),
(79, 'Unit registered successfully', 43, 4, 38, '2023-08-18 03:43:11', '2023-08-18 03:43:11'),
(80, 'Expense Category registered successfully', 43, 7, 38, '2023-08-18 04:26:22', '2023-08-18 04:26:22'),
(81, 'Expense added successfully', 43, 1, 38, '2023-08-18 04:27:18', '2023-08-18 04:27:18'),
(82, 'Supplier saved successfully', 43, 5, 38, '2023-08-19 13:31:26', '2023-08-19 13:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `barcodes`
--

CREATE TABLE `barcodes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `bar_code` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `batches`
--

CREATE TABLE `batches` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `batchno` varchar(255) NOT NULL,
  `expirydate` date NOT NULL,
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `businesses`
--

CREATE TABLE `businesses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `business_email` varchar(255) NOT NULL,
  `business_contact` varchar(255) NOT NULL,
  `business_address` varchar(255) NOT NULL,
  `business_logo` varchar(255) DEFAULT NULL,
  `business_enddate` date DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `businesses`
--

INSERT INTO `businesses` (`id`, `business_name`, `business_email`, `business_contact`, `business_address`, `business_logo`, `business_enddate`, `status`, `created_at`, `updated_at`) VALUES
(38, 'Restuarant', 'rest@gmail.com', '09877899', 'kira', '1691067274.png', '2023-12-20', 1, '2023-08-03 09:54:34', '2023-08-21 04:04:55'),
(39, 'Bar', 'bar@gmail.com', '09999999', 'wandegeya', '1692021489.jpeg', '2023-08-24', 1, '2023-08-14 10:58:09', '2023-08-14 10:58:09');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `selling_priceid` varchar(255) NOT NULL,
  `business_id` bigint(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coreproducts`
--

CREATE TABLE `coreproducts` (
  `id` int(20) UNSIGNED NOT NULL,
  `core_product` varchar(255) NOT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `business_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expensecategories`
--

CREATE TABLE `expensecategories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) DEFAULT NULL,
  `expense_category` varchar(255) NOT NULL,
  `status` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `expensecategories`
--

INSERT INTO `expensecategories` (`id`, `business_id`, `expense_category`, `status`, `created_at`, `updated_at`) VALUES
(3, 38, 'Lunch', 1, '2023-08-18 04:26:22', '2023-08-18 04:26:22');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `expense_name` varchar(255) NOT NULL,
  `expense_amount` varchar(255) NOT NULL,
  `expense_date` varchar(255) NOT NULL,
  `expense_description` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `business_id` bigint(20) DEFAULT NULL,
  `expensecategory_id` int(11) DEFAULT NULL,
  `enroll` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `expense_name`, `expense_amount`, `expense_date`, `expense_description`, `status`, `business_id`, `expensecategory_id`, `enroll`, `created_at`, `updated_at`) VALUES
(7, 'meals', '8000', '2023-08-18', 'matooke rice', 1, 38, 3, 1, '2023-08-18 04:27:18', '2023-08-18 04:27:18');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `flyroles`
--

CREATE TABLE `flyroles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rolename` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `business_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `flyroles`
--

INSERT INTO `flyroles` (`id`, `rolename`, `status`, `business_id`, `created_at`, `updated_at`) VALUES
(1, 'Secretary', 1, 20, '2023-04-20 15:13:41', '2023-04-20 15:13:41'),
(2, 'Doctor', 1, 18, '2023-04-24 02:40:15', '2023-04-24 02:40:15'),
(3, 'Sec', 1, 18, '2023-04-24 09:57:50', '2023-04-24 09:57:50');

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE `leaves` (
  `id` int(11) NOT NULL,
  `staffuser_id` varchar(255) NOT NULL,
  `leave_name` varchar(255) NOT NULL,
  `leave_days` int(11) NOT NULL,
  `business_id` bigint(22) NOT NULL,
  `status` int(22) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`id`, `staffuser_id`, `leave_name`, `leave_days`, `business_id`, `status`, `created_at`, `updated_at`) VALUES
(1, '28', 'medical', 2, 38, 1, '2023-08-22 09:18:55', '2023-08-22 09:18:55'),
(2, '28', 'efgr', 2, 38, 1, '2023-08-22 10:04:44', '2023-08-22 10:04:44'),
(3, '28', 'now', 4, 38, 1, '2023-08-22 10:06:08', '2023-08-22 10:06:08');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `from` bigint(22) NOT NULL,
  `message` varchar(255) NOT NULL,
  `is_read` tinyint(4) NOT NULL DEFAULT 0,
  `business_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `from`, `message`, `is_read`, `business_id`, `status`, `created_at`, `updated_at`) VALUES
(4, 43, 'foot', 0, 38, 1, '2023-08-17 06:07:06', '2023-08-17 06:07:06'),
(5, 43, 'natgasfooter', 0, 38, 1, '2023-08-17 07:39:28', '2023-08-17 07:39:28'),
(6, 45, 'challenge', 0, 38, 1, '2023-08-17 10:16:15', '2023-08-17 10:16:15'),
(7, 45, 'du', 0, 38, 1, '2023-08-17 10:18:07', '2023-08-17 10:18:07'),
(8, 43, 'mbako', 0, 38, 1, '2023-08-18 04:40:06', '2023-08-18 04:40:06');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_01_09_082838_create_orders_table', 1),
(6, '2023_01_09_083252_create_order__details_table', 1),
(7, '2023_01_09_083605_create_products_table', 1),
(8, '2023_01_12_170543_create_productcategories_table', 1),
(9, '2023_01_14_172227_create_barcodes_table', 1),
(10, '2023_01_14_181844_create_purchases_table', 1),
(11, '2023_01_14_194943_create_expenses_table', 1),
(12, '2023_01_16_062103_create_suppliers_table', 1),
(13, '2023_01_16_071011_create_pos_table', 1),
(14, '2023_01_19_173532_create_stocks_table', 1),
(15, '2023_01_25_130357_create_units_table', 1),
(16, '2023_01_25_135733_create_carts_table', 1),
(17, '2023_01_30_144302_create_sales_table', 1),
(18, '2023_02_01_124137_create_saledetails_table', 1),
(19, '2023_02_02_091836_create_stockcarts_table', 1),
(20, '2023_03_02_090711_create_audits_table', 1),
(21, '2023_03_03_123823_create_toasties_table', 1),
(22, '2023_03_06_130455_create_userpermissions_table', 1),
(23, '2023_03_06_135904_create_salesreports_table', 1),
(24, '2023_03_07_175040_create_stockreports_table', 1),
(25, '2023_03_08_061032_create_staff_table', 1),
(26, '2023_03_27_134712_create_businesses_table', 2),
(27, '2023_03_29_131515_laratrust_setup_tables', 3),
(28, '2023_01_12_170546_create_expensecategories_table', 4),
(29, '2023_04_20_173607_create_flyrole_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order__details`
--

CREATE TABLE `order__details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_id` int(11) NOT NULL,
  `unitprice` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('dan@gmail.com', '$2y$10$j3m07s2iUJ/.Q4lJYygudujYDFBOENElIPsNRLcTxchrIptXmB8yO', '2023-04-06 03:07:03');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'users-create', 'Create Users', 'Create Users', '2023-03-29 10:25:41', '2023-03-29 10:25:41'),
(2, 'users-read', 'Read Users', 'Read Users', '2023-03-29 10:25:41', '2023-03-29 10:25:41'),
(3, 'users-update', 'Update Users', 'Update Users', '2023-03-29 10:25:41', '2023-03-29 10:25:41'),
(4, 'users-delete', 'Delete Users', 'Delete Users', '2023-03-29 10:25:41', '2023-03-29 10:25:41'),
(5, 'payments-create', 'Create Payments', 'Create Payments', '2023-03-29 10:25:41', '2023-03-29 10:25:41'),
(6, 'payments-read', 'Read Payments', 'Read Payments', '2023-03-29 10:25:41', '2023-03-29 10:25:41'),
(7, 'payments-update', 'Update Payments', 'Update Payments', '2023-03-29 10:25:41', '2023-03-29 10:25:41'),
(8, 'payments-delete', 'Delete Payments', 'Delete Payments', '2023-03-29 10:25:41', '2023-03-29 10:25:41'),
(9, 'profile-read', 'Read Profile', 'Read Profile', '2023-03-29 10:25:42', '2023-03-29 10:25:42'),
(10, 'profile-update', 'Update Profile', 'Update Profile', '2023-03-29 10:25:42', '2023-03-29 10:25:42');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(9, 2),
(10, 1),
(10, 2);

-- --------------------------------------------------------

--
-- Table structure for table `permission_user`
--

CREATE TABLE `permission_user` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `user_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pos`
--

CREATE TABLE `pos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `productcategories`
--

CREATE TABLE `productcategories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `productcategories`
--

INSERT INTO `productcategories` (`id`, `category_name`, `image`, `status`, `business_id`, `created_at`, `updated_at`) VALUES
(12, 'Fruits', '1691945784.jpg', 1, 38, '2023-08-12 04:50:09', '2023-08-13 13:56:24'),
(13, 'Poultry', '1691945724.png', 1, 38, '2023-08-13 13:55:09', '2023-08-13 13:55:24');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_categoryid` varchar(255) NOT NULL,
  `selling_price` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `barcode` text DEFAULT NULL,
  `unit_id` varchar(255) NOT NULL,
  `alert_stock` int(11) NOT NULL,
  `buying_price` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `expirydate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_categoryid`, `selling_price`, `quantity`, `product_code`, `barcode`, `unit_id`, `alert_stock`, `buying_price`, `status`, `expirydate`, `batchno`, `business_id`, `created_at`, `updated_at`) VALUES
(22, 'Apples', '12', '2000', '15', '102521694', '<div style=\"font-size:0;position:relative;width:282px;height:60px;\">\r\n<div style=\"background-color:black;width:4px;height:60px;position:absolute;left:0px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:4px;height:60px;position:absolute;left:6px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:12px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:16px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:24px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:28px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:32px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:36px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:44px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:48px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:52px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:60px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:68px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:72px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:76px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:84px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:88px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:92px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:100px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:108px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:112px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:120px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:124px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:128px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:132px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:140px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:144px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:148px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:156px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:164px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:168px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:172px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:176px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:184px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:188px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:196px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:204px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:208px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:212px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:216px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:224px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:228px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:236px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:240px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:244px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:248px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:256px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:6px;height:60px;position:absolute;left:260px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:4px;height:60px;position:absolute;left:268px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:2px;height:60px;position:absolute;left:274px;top:0\">&nbsp;</div>\r\n<div style=\"background-color:black;width:4px;height:60px;position:absolute;left:278px;top:0\">&nbsp;</div>\r\n</div>\r\n', '12', 3, '2000', 1, NULL, NULL, 38, '2023-08-12 04:51:33', '2023-08-19 13:47:35');

-- --------------------------------------------------------

--
-- Table structure for table `purchasecarts`
--

CREATE TABLE `purchasecarts` (
  `id` int(11) NOT NULL,
  `coreproduct_id` bigint(20) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `buyingunit` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `expirydate` varchar(255) NOT NULL,
  `batchno` varchar(255) NOT NULL,
  `business_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchasedetails`
--

CREATE TABLE `purchasedetails` (
  `id` int(11) NOT NULL,
  `coreproduct_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `buyingunit` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `batchno` varchar(255) NOT NULL,
  `expirydate` varchar(255) NOT NULL,
  `business_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `discount` varchar(255) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `supplier_contact` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'superadministrator', 'Superadministrator', 'Superadministrator', '2023-03-29 10:25:40', '2023-03-29 10:25:40'),
(2, 'user', 'User', 'User', '2023-03-29 10:25:42', '2023-03-29 10:25:42');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `user_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`role_id`, `user_id`, `user_type`) VALUES
(1, 12, 'App\\Models\\User'),
(1, 13, 'App\\Models\\User'),
(2, 14, 'App\\Models\\User');

-- --------------------------------------------------------

--
-- Table structure for table `saledetails`
--

CREATE TABLE `saledetails` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `sale_id` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `selling_priceid` varchar(255) NOT NULL,
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `saledetails`
--

INSERT INTO `saledetails` (`id`, `product_id`, `sale_id`, `qty`, `selling_priceid`, `business_id`, `created_at`, `updated_at`) VALUES
(74, 22, '61', '1', '2000', 38, '2023-08-18 04:44:18', '2023-08-18 04:44:18'),
(75, 22, '62', '3', '2000', 38, '2023-08-18 04:47:10', '2023-08-18 04:47:10'),
(76, 22, '63', '1', '2000', 38, '2023-08-19 13:47:35', '2023-08-19 13:47:35');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_contact` varchar(255) DEFAULT NULL,
  `business_id` bigint(20) DEFAULT NULL,
  `product_total` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `total`, `paid`, `date`, `discount`, `customer_name`, `customer_contact`, `business_id`, `product_total`, `created_at`, `updated_at`) VALUES
(61, '1000', '3000', '2023-08-18', '1', 'Alice', '0755555', 38, '2000', '2023-08-18 04:44:18', '2023-08-18 04:44:18'),
(62, '2000', '8000', '2023-08-18', NULL, NULL, NULL, 38, '6000', '2023-08-18 04:47:10', '2023-08-18 04:47:10'),
(63, '7000', '9000', '2023-08-19', '8', 'christine', '0755444990', 38, '2000', '2023-08-19 13:47:34', '2023-08-19 13:47:34'),
(64, '7000', '9000', '2023-08-19', '8', 'christine', '0755444990', 38, '2000', '2023-08-19 13:58:37', '2023-08-19 13:58:37'),
(65, '7000', '9000', '2023-08-19', '8', 'christine', '0755444990', 38, '2000', '2023-08-19 13:59:29', '2023-08-19 13:59:29'),
(66, '7000', '9000', '2023-08-19', '8', 'christine', '0755444990', 38, '2000', '2023-08-19 13:59:54', '2023-08-19 13:59:54'),
(67, '7000', '9000', '2023-08-19', '8', 'christine', '0755444990', 38, '2000', '2023-08-19 14:05:15', '2023-08-19 14:05:15');

-- --------------------------------------------------------

--
-- Table structure for table `salesreports`
--

CREATE TABLE `salesreports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `staff_name` varchar(255) DEFAULT NULL,
  `staff_email` varchar(255) DEFAULT NULL,
  `staff_dob` varchar(255) DEFAULT NULL,
  `staff_contact` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `leave_days` int(22) DEFAULT NULL,
  `staff_address` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `enroll` int(11) NOT NULL DEFAULT 0,
  `business_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `staff_name`, `staff_email`, `staff_dob`, `staff_contact`, `gender`, `leave_days`, `staff_address`, `status`, `enroll`, `business_id`, `created_at`, `updated_at`) VALUES
(27, 'jack', 'jack@gmail.com', '2023-08-19', '0998765566', 'male', NULL, 'jinja', 1, 1, '38', '2023-08-17 08:27:14', '2023-08-17 08:27:30'),
(28, 'mary', 'mary@gmail.com', '1998-02-26', '0998765566', 'female', 30, 'bukoto', 1, 1, '38', '2023-08-22 06:43:40', '2023-08-22 10:06:08');

-- --------------------------------------------------------

--
-- Table structure for table `stockcarts`
--

CREATE TABLE `stockcarts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `qty_id` varchar(255) DEFAULT NULL,
  `buying_price` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stockreports`
--

CREATE TABLE `stockreports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `buying_price` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`id`, `product_id`, `qty`, `buying_price`, `date`, `business_id`, `created_at`, `updated_at`) VALUES
(19, '22', '15', '2000', '2023-08-12', 38, '2023-08-12 04:51:34', '2023-08-19 13:47:35');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `supplier_date` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `supplier_name`, `address`, `phone`, `email`, `supplier_date`, `status`, `business_id`, `created_at`, `updated_at`) VALUES
(3, 'Leo', 'Kisaasi', '098778987898', 'leo@gmail.com', '2023-08-20', 1, 38, '2023-08-19 13:31:26', '2023-08-19 13:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `business_id` int(22) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `title`, `description`, `business_id`, `created_at`, `updated_at`) VALUES
(2, 'foot', 'dghfgn', 38, '2023-08-17 06:07:08', '2023-08-17 06:07:08'),
(3, 'natgasfooter', 'uijkj', 38, '2023-08-17 07:39:32', '2023-08-17 07:39:32'),
(4, 'challenge', 'accepted', 38, '2023-08-17 10:16:18', '2023-08-17 10:16:18'),
(5, 'du', 'hast', 38, '2023-08-17 10:18:08', '2023-08-17 10:18:08'),
(6, 'mbako', 'i am here', 38, '2023-08-18 04:40:10', '2023-08-18 04:40:10');

-- --------------------------------------------------------

--
-- Table structure for table `toasties`
--

CREATE TABLE `toasties` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unit_name` varchar(255) NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `unit_name`, `symbol`, `status`, `business_id`, `created_at`, `updated_at`) VALUES
(13, 'Kilograms', 'kg', 1, 38, '2023-08-18 03:43:10', '2023-08-18 03:43:10');

-- --------------------------------------------------------

--
-- Table structure for table `userpermissions`
--

CREATE TABLE `userpermissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rolename` varchar(255) NOT NULL,
  `view_productcategory` tinyint(1) NOT NULL DEFAULT 0,
  `add_productcategory` tinyint(1) NOT NULL DEFAULT 0,
  `update_productcategory` tinyint(1) NOT NULL DEFAULT 0,
  `delete_productcategory` tinyint(1) NOT NULL DEFAULT 0,
  `view_product` tinyint(1) NOT NULL DEFAULT 0,
  `add_product` tinyint(1) NOT NULL DEFAULT 0,
  `update_product` tinyint(1) NOT NULL DEFAULT 0,
  `delete_product` tinyint(1) NOT NULL DEFAULT 0,
  `view_unit` tinyint(1) NOT NULL DEFAULT 0,
  `add_unit` tinyint(1) NOT NULL DEFAULT 0,
  `update_unit` tinyint(1) NOT NULL DEFAULT 0,
  `delete_unit` tinyint(1) NOT NULL DEFAULT 0,
  `view_supplier` int(11) NOT NULL DEFAULT 0,
  `add_supplier` int(11) NOT NULL DEFAULT 0,
  `update_supplier` int(11) NOT NULL DEFAULT 0,
  `delete_supplier` int(11) NOT NULL DEFAULT 0,
  `add_staff` int(11) NOT NULL DEFAULT 0,
  `view_staff` int(11) NOT NULL DEFAULT 0,
  `delete_staff` int(11) NOT NULL DEFAULT 0,
  `view_expense` int(11) NOT NULL DEFAULT 0,
  `add_expense` int(11) NOT NULL DEFAULT 0,
  `update_expense` int(11) NOT NULL DEFAULT 0,
  `delete_expense` int(11) NOT NULL DEFAULT 0,
  `view_stockcart` tinyint(1) NOT NULL DEFAULT 0,
  `view_audits` tinyint(1) NOT NULL DEFAULT 0,
  `view_stocklist` tinyint(1) NOT NULL DEFAULT 0,
  `view_cart` tinyint(1) NOT NULL DEFAULT 0,
  `view_barcode` tinyint(1) NOT NULL DEFAULT 0,
  `view_salesreport` int(11) NOT NULL DEFAULT 0,
  `view_stockreport` int(11) NOT NULL DEFAULT 0,
  `view_saleslist` int(11) NOT NULL DEFAULT 0,
  `view_permissions` int(11) NOT NULL DEFAULT 0,
  `business_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `userpermissions`
--

INSERT INTO `userpermissions` (`id`, `rolename`, `view_productcategory`, `add_productcategory`, `update_productcategory`, `delete_productcategory`, `view_product`, `add_product`, `update_product`, `delete_product`, `view_unit`, `add_unit`, `update_unit`, `delete_unit`, `view_supplier`, `add_supplier`, `update_supplier`, `delete_supplier`, `add_staff`, `view_staff`, `delete_staff`, `view_expense`, `add_expense`, `update_expense`, `delete_expense`, `view_stockcart`, `view_audits`, `view_stocklist`, `view_cart`, `view_barcode`, `view_salesreport`, `view_stockreport`, `view_saleslist`, `view_permissions`, `business_id`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, NULL, NULL, NULL),
(27, 'Admin', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 37, '2023-08-03 09:40:39', '2023-08-03 09:40:39'),
(28, 'Admin', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 38, '2023-08-03 09:54:34', '2023-08-03 09:54:34'),
(29, 'Admin', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 39, '2023-08-14 10:58:09', '2023-08-14 10:58:09'),
(30, 'Secretary', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 38, '2023-08-15 10:15:53', '2023-08-15 10:15:53'),
(31, 'Receptionist', 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 38, '2023-08-17 03:21:19', '2023-08-17 03:37:15');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `business_id` bigint(20) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `role_id`, `business_id`, `updated_at`) VALUES
(1, 'Dan', 'dan@gmail.com', NULL, '$2y$10$2yvJwJz0HRxS4LZIgtdoTOaF0Eou7A.CcR2c8zKp7O2vQwym8VdyO', 'rrM41LDXnd7DJDfLHVuIwut0z3wwEeOiDMZyv3B1VNMsOI2QvZoAAXfFPINZ', '2023-03-15 02:00:48', 0, NULL, '2023-03-15 02:00:48'),
(43, 'meg', 'meg@gmail.com', NULL, '$2y$10$.e5PzBqWX1HIpczu/YP85OIerQvGnWzXLV9LIULTch3qQxSzgqk1G', NULL, '2023-08-03 09:54:34', 28, 38, '2023-08-03 09:54:34'),
(44, 'bane', 'bane@gmail.com', NULL, '$2y$10$4jnYU6rpTRIUCHiTtKZQsu3I8KxmoyyMiSdb1NEhzIZ8xsDU46sru', NULL, '2023-08-14 10:58:09', 29, 39, '2023-08-14 10:58:09'),
(45, 'jack', 'jack@gmail.com', NULL, '$2y$10$5pZ26BMckXx7LBnrwwKvi.igwe2lpwL7q7sl2q6EJc5cZCmxn6st2', NULL, '2023-08-17 08:27:30', 31, 38, '2023-08-17 08:27:30'),
(46, 'mary', 'mary@gmail.com', NULL, '$2y$10$DXr79OPs38YZuwIRPgV2oO7B9Z09wpRkFngEW8mSUDAqhU2pjuYyW', NULL, '2023-08-22 06:53:04', 31, 38, '2023-08-22 06:53:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audits`
--
ALTER TABLE `audits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `barcodes`
--
ALTER TABLE `barcodes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `batches`
--
ALTER TABLE `batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `businesses_business_email_unique` (`business_email`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coreproducts`
--
ALTER TABLE `coreproducts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expensecategories`
--
ALTER TABLE `expensecategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `flyroles`
--
ALTER TABLE `flyroles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leaves`
--
ALTER TABLE `leaves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order__details`
--
ALTER TABLE `order__details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `permission_user`
--
ALTER TABLE `permission_user`
  ADD PRIMARY KEY (`user_id`,`permission_id`,`user_type`),
  ADD KEY `permission_user_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `pos`
--
ALTER TABLE `pos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productcategories`
--
ALTER TABLE `productcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchasecarts`
--
ALTER TABLE `purchasecarts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchasedetails`
--
ALTER TABLE `purchasedetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`user_id`,`role_id`,`user_type`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `saledetails`
--
ALTER TABLE `saledetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salesreports`
--
ALTER TABLE `salesreports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `staff_staff_email_unique` (`staff_email`);

--
-- Indexes for table `stockcarts`
--
ALTER TABLE `stockcarts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stockreports`
--
ALTER TABLE `stockreports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `toasties`
--
ALTER TABLE `toasties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userpermissions`
--
ALTER TABLE `userpermissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audits`
--
ALTER TABLE `audits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `barcodes`
--
ALTER TABLE `barcodes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `batches`
--
ALTER TABLE `batches`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `coreproducts`
--
ALTER TABLE `coreproducts`
  MODIFY `id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `expensecategories`
--
ALTER TABLE `expensecategories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `flyroles`
--
ALTER TABLE `flyroles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `leaves`
--
ALTER TABLE `leaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order__details`
--
ALTER TABLE `order__details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pos`
--
ALTER TABLE `pos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `productcategories`
--
ALTER TABLE `productcategories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `purchasecarts`
--
ALTER TABLE `purchasecarts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `purchasedetails`
--
ALTER TABLE `purchasedetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `saledetails`
--
ALTER TABLE `saledetails`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `salesreports`
--
ALTER TABLE `salesreports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `stockcarts`
--
ALTER TABLE `stockcarts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `stockreports`
--
ALTER TABLE `stockreports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `toasties`
--
ALTER TABLE `toasties`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `userpermissions`
--
ALTER TABLE `userpermissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `permission_user`
--
ALTER TABLE `permission_user`
  ADD CONSTRAINT `permission_user_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
